Instagram profile batch scan archived after repeated HTTP 429 / HTTP 400 spam:true responses. Disabled in the UI. Standalone Instagram post downloads remain available.
